MoEngage Flow Stats -> Excel + SQLite (fully automated)
===========================================================

What this does
---------------
Run ONE command. It automatically finds every real flow in the MoEngage
account (150 confirmed), reads every node in every one of them, and pulls
real Sent / Delivered / Opens / Clicks / Conversions / Revenue for every
WhatsApp/Email/Push send - no flow ID to look up, no picking a branch at
each step, nothing to type in while it runs. Output is one Excel file and
one SQLite database, each with one row per node per flow (2,108 rows /
150 flows in the last test run).

Setup (one time)
------------------
1. Install Python 3 if you don't have it: https://www.python.org/downloads/
2. Open a terminal in this folder and run:
     pip install requests python-dotenv pandas openpyxl
3. Copy .env.example to a new file named .env (same folder), and fill in
   your real MoEngage credentials (Settings -> Account -> APIs in the
   MoEngage dashboard):
     MOENGAGE_WORKSPACE_ID
     MOENGAGE_DATA_API_KEY
     MOENGAGE_CAMPAIGN_API_KEY
     MOENGAGE_DC     (e.g. "05" - check your dashboard URL, dashboard-0X.moengage.com)

Run it
-------
   python3 dump_all_flow_stats.py

That's the whole interface - no arguments needed. It will print progress
as it goes (fetching ~150 flows, then pulling stats for ~500 campaigns) -
takes a few minutes for the whole account. When it's done you'll have:

   flow_stats_dump.xlsx   <- open this in Excel
   flow_stats_dump.db     <- same data, as a SQLite table "flow_node_stats"

Optional flags (none required):
   --days 30              lookback window for the stats (default 30)
   --status ACTIVE PAUSED only include these flow statuses (default: all)

What's in each row
--------------------
Every row is one node (one step) inside one flow: its label, type, and
which branch it's under (path_label). For a WhatsApp/Email/Push send
node specifically, you also get:
   attempted, sent, delivered, opened, adjusted_opened, clicked,
   conversions, revenue
(all real numbers from MoEngage, for the date window shown in
date_range_start/date_range_end). Non-send steps (waits, conditions,
branch splits) show up too for context, just without those columns filled
in - MoEngage doesn't expose a live "Entered" count for those account-wide
in a way that's fast/reliable enough to include here by default (see
"Going deeper" below if you want that for one specific flow).

Re-running
-----------
Safe to re-run anytime (e.g. daily/weekly) - each run fully replaces both
output files with a fresh snapshot of the whole account, it doesn't pile
up old rows.

Going deeper on one flow (optional, not required for the main dump)
-----------------------------------------------------------------------
flow_node_stats_to_db.py is a slower, single-flow tool that ALSO
approximates each step's own Entered/Drop-off count (via MoEngage's
Funnels API) - useful if you want that number for one specific flow you
care about, at the cost of being much slower and only covering one flow
at a time (that's why it's not what dump_all_flow_stats.py uses for the
whole account). Usage:
   python3 flow_node_stats_to_db.py --search "Abandon Cart"      (find the flow_id)
   python3 flow_node_stats_to_db.py --flow-id <paste it> --days 30
Writes to flow_node_stats.db (a different file from the main dump above).
